The website may not work correctly if its not connected to th internet 



